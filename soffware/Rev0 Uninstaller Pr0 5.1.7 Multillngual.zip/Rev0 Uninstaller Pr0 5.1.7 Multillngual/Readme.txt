
1. Install and run once then close
2. Copy license "revouninstallerpro5.lic" to:
C:\ProgramData\VS Revo Group\Revo Uninstaller Pro\
3. Enjoy!


